import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
*Universidad del Valle de Guatemala                           
*11 calle 1579 Zona 15 Vista Hermosa III                     
*Guatemala, C. A.                                             
*Curso: Programación orientada a objetos                      
*Catedrático: Lynette Garcia Perez                               
*Trabajo: Proyecto Juego en Greenfoot
*Autores: Daniel Armando Valdez Reyes|Carné: 21240            
*Sección: 20
*Descripcion: Primer nivel del juego
*Última fecha de modificación: 22 de julio de 2021            
*Universidad del Valle 17 de julio de 2021. Segundo ciclo   
**/

public class Mundoprueba extends MyWorld
{

    /**
     * Constructor for objects of class Mundoprueba.
     * 
     */
    int base=64;
    int basey=-base;
    int x=-1444;
    int y=700;
   int livese=3;
    public Mundoprueba() {
        super(850,550,1, 3800,2100);
        setMainActor(new Primer_jugador(), 400,200);
        mainActor.setLocation(-1300, 500);
        GreenfootImage bg = new GreenfootImage("Vector-design-city-skyscrapers-night_3840x2160.jpg");
        setScrollingBackground(bg);
        prepare();
        addObject(new Vida(),128,48, false);
        //musica();
    }
    private void prepare(){
        //base+x
        //basey+y
        piso();
        enemigos();
        addObject(new bloque(),8*base+x, basey+y);
        addObject(new bloque(),8*base+x, 2*basey+y);
        addObject(new bloque(),10*base+x, 4*basey+y);
        addObject(new Fondo(5),13*base+x, 5*basey+y);
        addObject(new bloque(),16*base+x, 6*basey+y);
        addObject(new bloque(),17*base+x, 7*basey+y);
        addObject(new Fondo(5),20*base+x, 8*basey+y);
        addObject(new bloque(),23*base+x, 9*basey+y);
        addObject(new bloque(),24*base+x, 10*basey+y);
        addObject(new bloque(),25*base+x, 11*basey+y);
        addObject(new bloque(),26*base+x, 12*basey+y);
        addObject(new bloque(),27*base+x, 13*basey+y);
        addObject(new bloque(),28*base+x, 14*basey+y);
        addObject(new bloque(),29*base+x, 15*basey+y);
        addObject(new bloque(),30*base+x, 16*basey+y);
        addObject(new bloque(),31*base+x, 17*basey+y);
        addObject(new bloque(),32*base+x, 18*basey+y);
        addObject(new Fondo(15),40*base+x, 19*basey+y);
        
        addObject(new bloque(),22*base+x, basey+y);
        addObject(new bloque(),22*base+x, 2*basey+y);
        addObject(new bloque(),23*base+x, 3*basey+y);
        addObject(new bloque(),24*base+x, 4*basey+y);
        addObject(new Fondo(5),27*base+x,5*basey+y);
        addObject(new bloque(),30*base+x, 6*basey+y);
        addObject(new bloque(),31*base+x, 7*basey+y);
        addObject(new Fondo(5),34*base+x, 8*basey+y);
        
    }
    private void enemigos(){
        addObject(new Enfermo1(),20*base+x, basey+y);
        addObject(new Enfermo1(),16*base+x, basey+y);
        addObject(new Enfermo1(),12*base+x, basey+y);
    }
    private void primerparte(){
        
    
    }
    private void piso(){
        addObject(new Ladrillo(59), 412, 700);
        addObject(new Fondo(59), 412, 764);
        addObject(new Fondo(59), 412, 828);
    
    }
}
