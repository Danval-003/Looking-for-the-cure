import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
*Universidad del Valle de Guatemala                           
*11 calle 1579 Zona 15 Vista Hermosa III                     
*Guatemala, C. A.                                             
*Curso: Programación orientada a objetos                      
*Catedrático: Lynette Garcia Perez                               
*Trabajo: Proyecto Juego en Greenfoot
*Autores: Daniel Armando Valdez Reyes|Carné: 21240            
*Sección: 20
*Descripcion: incluye a todos los enemigos.
*Última fecha de modificación: 22 de julio de 2021            
*Universidad del Valle 17 de julio de 2021. Segundo ciclo   
**/

public class Enemigos extends Actor
{
    /**
     * Act - do whatever the Enemigos wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        // Add your action code here.
    }
}
