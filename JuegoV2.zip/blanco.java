import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class blanco here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class blanco extends MyWorld
{

    /**
     * Constructor for objects of class blanco.
     * 
     */
    public blanco()
    {
        super(850,550,1, 3800,2100);
    }
}
